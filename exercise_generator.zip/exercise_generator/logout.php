<?php
	//Ako se ne definira metoda slanja, ona je uvijek GET
	include 'controllers/UserController.php';
	if($_SERVER['REQUEST_METHOD'] == 'GET') {
		$_SESSION['error-logout'] = '';
		$user = new UserController(DB_DSN, DB_USERNAME, DB_PASSWORD);
		$user->userLogout();
	} else {
		$_SESSION['error-logout'] = "Greška kod odjave korisnika!";
		header('location: index.php');
	}
?>