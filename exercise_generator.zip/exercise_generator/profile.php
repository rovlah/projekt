<?php
	include 'controllers/ExerciseController.php'; 
	$isAuth = false;
	
	if(isset($_SESSION['auth'])) { // 1. uvjet
		if($_SESSION['auth'] == true) { // 2. uvjet
			$isAuth = $_SESSION['auth'];
		} // kraj 2. uvjeta
		else 
		{ // 2. else uvjet
			header('location: index.php');
		} // keaj 2. else uvjeta
	} // kraj 1. uvjeta
	
	if($isAuth == false) { 
		die('Pristup zabranjen'); 
	}
	
	$exercise = new ExerciseController(DB_DSN, DB_USERNAME, DB_PASSWORD);
	
	$userData = $exercise->userData($_SESSION['id']);
	
	$userExercises = $exercise->userExercises($_SESSION['id']);

	
?>


<!doctype html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Profil | Exercise Generator</title>
		<?php include 'assets/css.php'; ?>
	<head>
	
	<body>
		<div class="container">
		<div class="col-md-6">
			<h1 class="text-center" style="font-size: 50px; font-family: Garamond; color: grey; ">Administrator <?php echo $userData['ime_korisnika'].' '; echo $userData['prezime_korisnika'];?></h1>
			<hr>
			<?php include 'assets/navigation.php'; ?>
			
					<h1 class="text-center" style="font-family: Garamond; color: grey;">Vježbe</h3>
					<hr>
					<a href="insertExercise.php" class="btn btn-info btn-block">Unos vježbi</a>
					<br><br>
					<?php if(!empty($userExercises)): ?>
						<table class="table">
							<tr>
								<th>Naziv vježbe</th>
								<th>Poveznica za snimku vježbe</th>
								<th>Ažuriranje</th>
								<th>Brisanje</th>
							</tr>
							<?php foreach($userExercises as $exercise): ?>
								<tr>
									<td><?php echo $exercise['naziv_vjezbe']; ?></td>
									<td><?php echo $exercise['video_link']; ?></td>
									<td><a href="updateExercise.php?exercise=<?php echo $exercise['id_vjezbe']; ?>" class="btn btn-warning">Izmjena</a></td>
									<td><a href="deleteExercise.php?exercise=<?php echo $exercise['id_vjezbe']; ?>" class="btn btn-warning">Brisanje</a></td>
								</tr>
							<?php endforeach; ?>
						</table>
					<?php endif; ?>
				</div> <!-- kraj diva 8 -->
			
		</div>
		
		
		<?php include 'assets/js.php'; ?>
	</body>
</html>

