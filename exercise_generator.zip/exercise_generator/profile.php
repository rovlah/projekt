<?php
	include 'controllers/ExerciseController.php'; 
	$isAuth = false;
	
	if(isset($_SESSION['auth'])) { // 1. uvjet
		if($_SESSION['auth'] == true) { // 2. uvjet
			$isAuth = $_SESSION['auth'];
		} // kraj 2. uvjeta
		else 
		{ // 2. else uvjet
			header('location: index.php');
		} // keaj 2. else uvjeta
	} // kraj 1. uvjeta
	
	if($isAuth == false) { 
		die('Pristup zabranjen'); 
	}
	
	$exercise = new ExerciseController(DB_DSN, DB_USERNAME, DB_PASSWORD);
	
	$userData = $exercise->userData($_SESSION['id']);
	
	$userExercises = $exercise->userExercises($_SESSION['id']);

	
?>


<!doctype html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Popis vježbi</title>
		<?php include 'assets/css.php'; ?>
	<head>
	
	<body>
		<div class="container">
			<h1>Dobro došli <?php echo $userData['ime_korisnika'].' '; echo $userData['prezime_korisnika']; ?></h1>
			<hr>
			<?php include 'assets/navigation.php'; ?>
			
			<div class="row">
				<div class="col-md-4"> <!-- početak diva 4 -->
					<h3>Osobni podaci</h3>
					<hr>
					<label>Ime: <?php echo $userData['ime_korisnika']; ?></label><br>
					<label>Prezime: <?php echo $userData['prezime_korisnika']; ?></label><br>
					<label>E-mail: <?php echo $userData['email']; ?></label><br>
					<a href="updatePassword.php">Ažuriraj lozinku</a>

				</div> <!-- kraj diva 4 -->
				
				<div class="col-md-8"> <!-- početak diva 8 -->
					<h3>Vježbe</h3>
					<hr>
					<a href="insertExercise.php">Unos vježbi</a>
					<?php if(!empty($userExercises)): ?>
						<table class="table">
							<tr>
								<th>Naziv vježbe</th>
								<th>Broj serija</th>
								<th>Broj ponavljanja</th>
								<th>Trajanje</th>
								<th>Opis</th>
								<th>Poveznica videozapisa</th>
								<th>Ažuriranje</th>
								<th>Brisanje</th>
							</tr>
							<?php foreach($userExercises as $exercise): ?>
								<tr>
									<td><?php echo $exercise['naziv_vjezbe']; ?></td>
									<td><?php echo $exercise['broj_serija']; ?></td>
									<td><?php echo $exercise['broj_ponavljanja']; ?></td>
									<td><?php echo $exercise['trajanje']; ?></td>
									<td><?php echo $exercise['opis']; ?></td>
									<td><?php echo $exercise['video_link']; ?></td>
									<td><a href="updateExercise.php?exercise=<?php echo $exercise['id_vjezbe']; ?>">Izmjena</a></td>
									<td><a href="deleteExercise.php?exercise=<?php echo $exercise['id_vjezbe']; ?>">Brisanje</a></td>
								</tr>
							<?php endforeach; ?>
						</table>
					<?php endif; ?>
				</div> <!-- kraj diva 8 -->
			
			</div>
		
		</div>
		
		
		<?php include 'assets/js.php'; ?>
	</body>
</html>

