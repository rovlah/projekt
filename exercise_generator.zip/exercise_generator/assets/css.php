<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<style>
body{
	background-image: url(https://wallpaper.wiki/wp-content/uploads/2017/05/wallpaper.wiki-Running-Backgrounds-HD-PIC-WPD001013.jpg);
	background-size: cover;
}

</style>