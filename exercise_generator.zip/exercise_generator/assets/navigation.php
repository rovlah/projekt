<!DOCTYPE html>
<html>
<head>
<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #fff;
	border: 1px solid black;
}

li {
    float: left;
}

li a {
    display: block;
    color: black;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
    color: pink;
	text-decoration: none;
}
</style>
</head>
<body>

<p> <!-- Lista za kretanje po stranici -->
	<ul>
		<li><a href="index.php">Početna stranica</a></li>
		<?php if($_SESSION['auth'] == false): ?>
			<li><a href="register.php">Registracija</a></li>
		<?php endif; ?>
		<?php if($_SESSION['auth'] == true): ?>
			<li><a href="profile.php">Profil</a></li>
			<li><a href="logout.php">Odjava</a></li>
		<?php endif; ?>
	</ul>
</p>

</body>
</html>