<!DOCTYPE html>
<html>
<head>
<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: rgb(255, 235, 187);
	border: 1px solid black;
}

li {
    float: left;
}

li a {
    display: block;
    color: black;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
    color: grey;
	text-decoration: none;
}
</style>
</head>
<body>
<?php if($_SESSION['auth'] == true): ?>
<p> <!-- Lista za kretanje po stranici -->
	<ul>
			<li><a href="profile.php">Profil</a></li>
			<li><a href="insertExercise.php">Dodaj novu vježbu</a></li>
			<li><a href="updatePassword.php">Izmjena lozinke</a></li>
			<li><a href="logout.php">Odjava</a></li>
	</ul>
</p>
<?php endif; ?>
</body>
</html>