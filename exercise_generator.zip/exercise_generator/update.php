<?php 
    include 'controllers/ExerciseController.php'; 
    //Ako je metoda POST
    if($_SERVER['REQUEST_METHOD'] == 'POST') {
        if(!empty($_POST)) {
            $notValid = [];
            $data = [];
            foreach($_POST as $key => $value) {
                if($key != 'updateExercise') {
                    if($key == 'brojSerija' || 'brojPonavljanja' || 'trajanje' || 'poveznicaVideo') {
                        $data[$key] = !empty($value) ? $value : '';
                    } else {
                        if(!empty($value)) {
                            $data[$key] = $value;
                        } else {
                            $notValid[] = $key;
                        }
                    }
                }
            }

            if(empty($notValid)) {
                $_SESSION['error-update'] = '';
                $exercise = new ExerciseController(DB_DSN, DB_USERNAME, DB_PASSWORD);
                $result = $exercise->updateExercise($data);
                
                if($result['type'] == 'ok') {
                    $_SESSION['error-update'] = $result['content'];
                    header('location: profile.php');
                } else {
                    $_SESSION['error-update'] = $result['content'];
                    header('location: updateExercise.php?exercise=' .$data['exercise']);
                }
            } else {
                $_SESSION['error-update'] = "Molimo unesite sve podatke označene zvjezdicom";
                header('location: updateExercise.php?exercise=' . $data['exercise']);
            }
        } else {
            $_SESSION['error-update'] = "Molimo ispunite sve podatke označene zvjezdicom";
            header('location: updateExercise.php?exercise=' . $data['exercise']);
        }
    } else {
        die('Zapranjen pristup');
    }
?>