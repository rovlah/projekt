<?php include 'controllers/UserController.php'; ?>

<!doctype html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Dobro došli na Algebra contacts stranice</title>
		
		<?php include "assets/css.php"; ?>
	</head>
	
	<body>
	
		<div class="container text-center">
			<h1 class="text-center">Exercise Generator</h1>
			<hr>
			<?php include 'assets/navigation.php'; ?>
			<?php if($_SESSION['auth'] != true): ?>
			<p>
				Za pristup sadržaju stranice potreban vam je korisnički račun
				<br>
				<a class="btn btn-primary" href="register.php">Registracija</a>
			</p>
			
			<br><br>
			<p>
				<?php if(isset($_SESSION['error-login'])): //1. uvjet ?>
					<?php if(!empty($_SESSION['error-login'])): //2. uvjet ?>
						<div class="alert alert-danger"><?php echo $_SESSION['error-login']; ?></div>
					<?php endif; // kraj 2. uvjeta ?>
				<?php endif; // kraj 1. uvjeta ?>
				
				<form class="col-md-4 offset-md-4 text-center" method="POST" action="login.php">
					<div class="form-group">
						<label>Korisničko ime</label>
						<input type="text" name="username" class="form-control" />
					</div>
					
					<div class="form-group">
						<label>Lozinka</label>
						<input type="password" name="password" class="form-control" />
					</div>
					
					<div class="form-group">
						<input class="btn btn-success" type="submit" name="login" value="Pošalji" />
					</div>
				</form>
			</p>
			<?php endif; ?>
		</div>
		
		
		
		<?php include "assets/js.php"; ?>
	</body>
</html>