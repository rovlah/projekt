<?php include 'controllers/UserController.php'; ?>

<!doctype html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Home | Exercise Generator</title>
		
		<?php include "assets/css.php"; ?>
	</head>
	
	<body>
	
		<div class="container text-center">
			<div class="col-md-6">
			<h1 class="text-center" style="font-size: 60px; color: grey; font-family: Garamond;">Exercise Generator</h1>
			<hr>
			<?php include 'assets/navigation.php'; ?>
			<?php if($_SESSION['auth'] != true): ?>
			<p>
				Dobrodošli u aplikaciju Exercise Generator! Ukoliko još niste naš korisnik, molimo Vas da se registrirate.
				<br><br>
				<a class="btn btn-secondary" href="register.php">Registracija</a>
			</p>
			
			<br><br>
			<p>
				<?php if(isset($_SESSION['error-login'])): //1. uvjet ?>
					<?php if(!empty($_SESSION['error-login'])): //2. uvjet ?>
						<div class="alert alert-danger"><?php echo $_SESSION['error-login']; ?></div>
					<?php endif; // kraj 2. uvjeta ?>
				<?php endif; // kraj 1. uvjeta ?>
				
				<form class="col-md-8 offset-md-2 text-center" method="POST" action="login.php">
					<div class="form-group">
						<label><b>Korisničko ime</b></label>
						<input type="text" name="username" class="form-control" />
					</div>
					
					<div class="form-group">
						<label><b>Lozinka</b></label>
						<input type="password" name="password" class="form-control" />
					</div>
					
					<div class="form-group">
						<input class="btn btn-info" type="submit" name="login" value="Prijavite se!" />
					</div>
				</form>
			</p>
			<?php endif; ?>
			</div>
		</div>
		
		
		
		<?php include "assets/js.php"; ?>
	</body>
</html>