<?php 
    include 'controllers/ExerciseController.php'; 
    if($_SERVER['REQUEST_METHOD'] == 'GET') {
        if(isset($_GET['exercise'])) {
            $exercise = new ExerciseController(DB_DSN, DB_USERNAME, DB_PASSWORD);
            $result = $exercise->deleteExercise($_GET['exercise'], $_SESSION['id']);

            
        } else {
            die('Pristup zabranjen');
        }
    } else {
        die('Pristup zabranjen');
    }

?>
