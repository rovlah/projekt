<?php
	include 'controllers/UserController.php';
	
	if(isset($_POST['register'])) {
		$errors = [];
		$data = [];
		
		foreach($_POST as $key => $value) {
			if($key != 'register') {
				if(!empty($value)) {
					if($key == 'password' || $key == 'passwordRepeat') {
						if($_POST['password'] == $_POST['passwordRepeat']) {
							$data['password'] = htmlspecialchars($value);
						} else {
							$errors[] = $key;
						}
					} else {
						$data[$key] = htmlspecialchars($value);
					}
				} else {
					$errors[] = $key;
				}
			}
		}
		
		if(empty($errors)) {
			$_SESSION['error-register'] = '';
			$user = new UserController(DB_DSN, DB_USERNAME, DB_PASSWORD);
			$user->userRegistration($data);
		} else {
			$_SESSION['error-register'] = "Molimo unesite sva polja";
		}
	}

?>


<!doctype html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Registracija | Exercise Generator</title>
		<?php include "assets/css.php"; ?>
	</head>

	<body>
		<div class="container text-center">
		<div class="col-md-6">
			<h1 style="font-size: 42px; font-family: Garamond; color: grey; ">Forma za registraciju korisnika</h1>
			<hr>
			
			<?php if(isset($_SESSION['error-register'])): ?>
				<?php if(!empty($_SESSION['error-register'])): ?>
					<div class="alert alert-danger"><?php echo $_SESSION['error-register']; ?></div>
				<?php endif; ?>
			<?php endif; ?>
			
			<form class="col-md-12" method="POST" action="">
				<div class="form-group">
					<label>Ime*</label>
					<input type="text" name="imeKorisnika" class="form-control" />
				</div>
				<div class="form-group">
					<label>Prezime*</label>
					<input type="text" name="prezimeKorisnika" class="form-control" />
				</div>
				<div class="form-group">
					<label>Korisničko ime*</label>
					<input type="text" name="korisnickoIme" class="form-control" />
				</div>
				<div class="form-group">
					<label>Lozinka*</label>
					<input type="password" name="password" class="form-control" />
				</div>
				<div class="form-group">
					<label>Ponovi lozinku*</label>
					<input type="password" name="passwordRepeat" class="form-control"/>
				</div>
				
				<div class="form-group">
					<label>E-mail*</label>
					<input type="email" name="email" class="form-control" />
				</div>
				
				<input type="submit" name="register" value="Registrirajte se!" class="btn btn-info" />
				<a href="index.php" class="btn btn-info">Natrag</a>
			</form>
		</div>
		</div>
	
		<?php include "assets/js.php"; ?>
	</body>
</html>