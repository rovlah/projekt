﻿<?php
	session_start();
	include 'assets/constants.php';
	
	
	class UserController {
		
		private $databaseConnection;
		
		//Definiranje konstruktora klase za spajanje na bazu podataka
		function __construct($dsn, $username, $password) {
			//Pokukušaj spajanja na bazu
			try {
				
				$this->databaseConnection = new PDO($dsn, $username, $password);
				$this->databaseConnection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
			} catch(PDOException $e) {
				echo $e->getMessage();
			}
		}
		
		
		//Funkcija za registraciju novog korisnika
		function userRegistration($params) {
			
			$hash = password_hash($params['password'], PASSWORD_BCRYPT);
			
			$query = 'INSERT INTO korisnik';
			$query .= ' (ime_korisnika, prezime_korisnika, email, korisnicko_ime, lozinka)';
			$query .= ' VALUES';
			$query .= ' (:imeKorisnika, :prezimeKorisnika, :email, :korisnickoIme, :password)';
			
			$unosKorisnika = $this->databaseConnection->prepare($query);
			
			$unosKorisnika->bindParam(':imeKorisnika', $params['imeKorisnika'], PDO::PARAM_STR, 40);
			$unosKorisnika->bindParam(':prezimeKorisnika', $params['prezimeKorisnika'], PDO::PARAM_STR, 50);
			$unosKorisnika->bindParam(':email', $params['email'], PDO::PARAM_STR, 100);
			$unosKorisnika->bindParam(':korisnickoIme', $params['korisnickoIme'], PDO::PARAM_STR, 50);
			$unosKorisnika->bindParam(':password', $hash, PDO::PARAM_STR, 100);
			
			try {
				$result = $unosKorisnika->execute();
				if($result == true) {
					header('location: index.php');
				} else {
					echo "Nije uspjelo!";
				}
				
			} catch(PDOException $e) {
				echo $e->getMessage();
			}
			
		}
		
		//Funkcija za prijavu korisnika 
		function userLogin($params) { //početak funkcije
			
			$query = "SELECT id_korisnika, korisnicko_ime, lozinka";
			$query .= " FROM korisnik";
			$query .= " WHERE korisnicko_ime = :korisnickoIme";
			
			$selectKorisnik = $this->databaseConnection->prepare($query);
			//Ne zaboraviti na povezivanje parametara
			$selectKorisnik->bindParam(':korisnickoIme', $params['username']);
			
			try { // početake try iznimke
				$selectKorisnik->execute();
				$result = $selectKorisnik->fetchAll();
				if(count($result) === 0) { // 1. uvjet
					$_SESSION['auth'] = false;
					$_SESSION['error-login'] = 'Korisnik ne postoji!';
					header('location: index.php');				
				} //kraj 1. uvjeta
				else { //početak 1. else uvjeta
					
					//hash unesene lozinke
					$password = $params['password'];
					$hash = $result[0]['lozinka'];
					if(password_verify($password, $hash)) { // 2. uvjet
						$_SESSION['auth'] = true;
						$_SESSION['user'] = $result[0]['username'];
						$_SESSION['id'] = $result[0]['id_korisnika'];

						if($result[0]['id_korisnika'] == 4){
							header('location: profile.php');
						} else {
						header('location: random.php');
						}
						
					} // kraj 2. uvjeta
					else { // 2. else uvjet
						$_SESSION['auth'] = false;
						$_SESSION['error-login'] = 'Prijava nije uspješna!';
						header('location: index.php');
					} // kraj 2. else uvjeta
					
				} //kraj 1. else uvjeta
				
				
			} //kraj try iznimke
			catch(PDOException $e) { //početak catch iznimke
				echo $e->getMessage();
			} //kraj catch iznimke
			
			
		} //kraj funkcije
		
		// Funkcija za odjavu korisnika 
		function userLogout() {
			session_unset();
			session_destroy();
			header('location: index.php');
		}

		//Funkcija za izmjenu lozinke
		function changePassword($params) { // početak funkcije
			
			$query = "SELECT id_korisnika, lozinka FROM korisnik WHERE id_korisnika = :id";

			$checkUser = $this->databaseConnection->prepare($query);
			$checkUser->bindParam(':id', $params['user']);
			$checkUser->execute();

			$userData = $checkUser->fetch(PDO::FETCH_ASSOC);

			//Prije izmjene lozinke potrebno je provjeriti da li je hash lozinki identičan
			if(password_verify($params['oldPassword'], $userData['lozinka'])) {

				//Ako se stara lozinka iz baze podataka i stara lozinka iz HTML forme podudaraju

				//Hash za novu lozinku
				$newPasswordHash = password_hash($params['password'], PASSWORD_BCRYPT);
				
				//Priprema SQL upita
				$queryPassword = "UPDATE korisnik SET ";
				$queryPassword .= "lozinka = :newPassword WHERE id_korisnika = :user";
				//Priprema, povezivanje parametara i izvršavanje upita
				$updatePassword = $this->databaseConnection->prepare($queryPassword);
				$updatePassword->bindParam(':newPassword', $newPasswordHash);
				$updatePassword->bindParam(':user', $params['user']);

				$result = $updatePassword->execute();
				if($result == true) {
					//Ako je update uspio
					$message = [
						'type' => 'ok',
						'content' => 'Ažuriranje lozinke je uspješno izvršeno!'
					];
				} else {
					//Ako update nije uspio
					$message = [
						'type' => 'error',
						'content' => 'Ažuriranje lozinke nije uspjelo!'
					];
				}

			} else {
				//Ako se lozinke ne podudaraju
				$message = [
					'type' => 'error',
					'content' => 'Stara lozinka nije ispravna!'
				];
			}

			return $message;
		} // kraj funkcije
		
		
		// kraj klase
	}

?>