<?php

	require 'UserController.php';
	
	class ExerciseController extends UserController {
		
		public $database;
		
		//funkcija konstruktora
		function __construct($dsn, $username, $password) {
			try {
				$this->database = new PDO($dsn, $username, $password);
				$this->database->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
			} catch (PDOException $e) {
				return $e->getMessage();
			}
		}
		
		//Funkcija za korisnika
		function userData($id) { //početak funkcije
			
			$query = "SELECT ime_korisnika, prezime_korisnika, email ";
			$query .= "FROM korisnik ";
			$query .= "WHERE id_korisnika = :id";
			
			$selectUser = $this->database->prepare($query);
			$selectUser->bindParam(':id', $id);
			
			$selectUser->execute();
			$user = $selectUser->fetch(PDO::FETCH_ASSOC);
			
			return $user;
			
		} //kraj funkcije
		
		//Funkcija za prikaz kontakata korisnika 
		function userExercises($id) { //početak funkcije
			
			$query = "SELECT vjezba.* ";
			$query .= "FROM vjezba ";
			$query .= "INNER JOIN korisnik ON vjezba.id_korisnika = korisnik.id_korisnika ";
			$query .= "WHERE vjezba.id_korisnika = :id";
			
			$selectExercises = $this->database->prepare($query);
			$selectExercises->bindParam(':id', $id);
			
			$selectExercises->execute();
			$exercises = $selectExercises->fetchAll(PDO::FETCH_ASSOC);
			

			
			return $exercises;
			
		} //kraj funkcije
		
		//Funkcija za unos kontakta
		function insertExercise($params) {

			$query = "INSERT INTO vjezba (naziv_vjezbe, broj_serija, broj_ponavljanja, trajanje, video_link, opis, id_korisnika)";
			$query .= "VALUES (:nazivVjezbe, :brojSerija, :brojPonavljanja, :trajanje, :videoLink, :opis, :idKorisnika)";

			$insertExercise = $this->database->prepare($query);
			
			$insertExercise->bindParam(':nazivVjezbe', $params['nazivVjezbe']);
			$insertExercise->bindParam(':brojSerija', $params['brojSerija']);
			$insertExercise->bindParam(':brojPonavljanja', $params['brojPonavljanja']);
			$insertExercise->bindParam(':trajanje', $params['trajanje']);
			$insertExercise->bindParam(':videoLink', $params['poveznicaVideo']);
			$insertExercise->bindParam(':opis', $params['opis']);
			$insertExercise->bindParam(':idKorisnika', $params['user']);

			$result = $insertExercise->execute();
			if($result == true) {
				header('location: profile.php');
			} else {
				$_SESSION['error-insert'] = "Unos nije uspio, molimo pokušajte ponovo!";
				header('location: insertExercise.php');
			}

		}

		function exerciseData($vjezba, $id) {

			$query = "SELECT * FROM vjezba WHERE id_vjezbe = :vjezba AND id_korisnika = :id";
			$selectExercise = $this->database->prepare($query);
			$selectExercise->bindParam(':vjezba', $vjezba);
			$selectExercise->bindParam(':id', $id);
			$selectExercise->execute();
			

			$data = $selectExercise->fetch(PDO::FETCH_ASSOC);

			if(!empty($data)) {
				return $data;
			} else {
				header('location: profile.php');
			}
		}
		
		//Funkcija za izmjenu kontakta
		function updateExercise($params) {
			
			//echo '<pre>';
			//var_dump($params);
			//echo '</pre>';
			//die();
			
			$query = "UPDATE vjezba SET ";
			$query .= "naziv_vjezbe = :nazivVjezbe, broj_serija = :brojSerija, broj_ponavljanja = :brojPonavljanja, trajanje = :trajanje, ";
			$query .= "video_link = :videoLink, opis = :opis WHERE id_vjezbe = :vjezba AND id_korisnika = :id";

			$updateExercise = $this->database->prepare($query);
			$updateExercise->bindParam(':nazivVjezbe', $params['nazivVjezbe']);
			$updateExercise->bindParam(':brojSerija', $params['brojSerija']);
			$updateExercise->bindParam(':brojPonavljanja', $params['brojPonavljanja']);
			$updateExercise->bindParam(':trajanje', $params['trajanje']);
			$updateExercise->bindParam(':videoLink', $params['poveznicaVideo']);
			$updateExercise->bindParam(':opis', $params['opis']);
			$updateExercise->bindParam(':vjezba', $params['exercise']);
			$updateExercise->bindParam(':id', $params['user']);

			$result = $updateExercise->execute();

			if($result == true) {
				$message = [
					'type' => 'ok',
					'content' => ''
				];
			} else {
				$message = [
					'type' => 'error',
					'content' => 'Dogodila se greška pri ažuriranju'
				];
			}

			return $message;
		}
		
		//Funkcija za brisanje kontakta
		function deleteExercise($vjezba, $id) {
			
			$query = "DELETE FROM vjezba WHERE id_vjezbe = :vjezba AND id_korisnika = :id";

			$deleteExercise = $this->database->prepare($query);
			$deleteExercise->bindParam(':vjezba', $vjezba);
			$deleteExercise->bindParam(':id', $id);

			$deleteExercise->execute();
			

			if($deleteExercise->rowCount() > 0) {
				header('location: profile.php');
			} else {
				$_SESSION['error-delete'] = "Dogodila se greška u brisanju";
				header('location: profile.php');
			}
			
		}
		
	//kraj klase	
	}
?>