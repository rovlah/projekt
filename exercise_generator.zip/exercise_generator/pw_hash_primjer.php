<?php

	echo "password_hash('12345', PASSWORD_DEFAULT) = " . password_hash('12345', PASSWORD_DEFAULT);
	echo "<br><br>";
	echo "password_hash('12345', PASSWORD_BCRYPT) = " . password_hash('12345', PASSWORD_BCRYPT);
	echo "<br><br>";
	echo "password_hash('12345', PASSWORD_ARGON2I ) = " . password_hash('12345', PASSWORD_ARGON2I);
	echo "<br><br>";

?>
	