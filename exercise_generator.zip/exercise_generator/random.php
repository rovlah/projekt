<?php
	header ('Content-type: text/html; charset=utf-8');
	$konekcija = mysql_connect("localhost", "root", "");
	mysql_select_db("exercise_generator", $konekcija);
	
	$brojanje = mysql_query("SELECT * FROM vjezba");
	$numrows = mysql_num_rows($brojanje);
	$random = rand(1, $numrows) - 1;
	$get = mysql_query("SELECT * FROM vjezba WHERE id_vjezbe > $random LIMIT 1");

?>

<!doctype html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<title>Današnja vježba | Exercise Generator</title>
		<?php include 'assets/css.php'; ?>
	</head>
	<body>
		<div class="container text-center">
		<div class="col-md-6">
			<h1 class="text-center" style="font-size: 50px; font-family: Garamond; color: grey; ">Profil korisnika </h1>
			<hr>
			<?php include 'assets/navigation.php'; ?>
			
				
				<div class="col-md-12"> <!-- početak diva 8 -->
					<hr>
					<p style="font-size: 20px;">
						Pozdrav! Aplikacija Exercise Generator nakon svakog ponovnog učitavanja stranice prikazuje 
						slučajno odabranu vježbu koju možete odraditi danas!
						<br>
						Današnja vježba je:
					</p>
					<p style="font-size: 40px; font-weight: 600;">
					<?php
					while($show = mysql_fetch_array($get)):
						echo $show["naziv_vjezbe"].'<br>';
					?>
					</p>
					<p style="font-size: 20px; font-weight: 600;">
					<?php
						echo '<b>Broj serija:</b> '.$show["broj_serija"].'<br>';
						echo '<b>Broj ponavljanja:</b> '.$show["broj_ponavljanja"].'<br>';
						echo '<b>Trajanje:</b> '.$show["trajanje"].'<br>';
						echo '<b>Snimka vježbe:</b> '.$show["video_link"].'<br>';
						echo '<b>Opis:</b> '.$show["opis"];
					endwhile;
					?>
					</p>

		</div>
		</div>
		</div>
		
		<?php include 'assets/js.php'; ?>
	</body>
</html>

