Koraci za projekt:

1. Kreirajte bazu podataka pod nazivom algebra_contacts.
2. Napravite import strukture baze podataka sa datotekom iz mape sql
