-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 19, 2018 at 12:56 PM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `exercise_generator`
--

-- --------------------------------------------------------

--
-- Table structure for table `korisnik`
--

CREATE TABLE `korisnik` (
  `id_korisnika` int(11) NOT NULL,
  `ime_korisnika` varchar(40) NOT NULL,
  `prezime_korisnika` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `korisnicko_ime` varchar(50) NOT NULL,
  `lozinka` longtext NOT NULL,
  `remember_token` longtext,
  `role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `korisnik`
--

INSERT INTO `korisnik` (`id_korisnika`, `ime_korisnika`, `prezime_korisnika`, `email`, `korisnicko_ime`, `lozinka`, `remember_token`, `role`) VALUES
(1, 'Pero', 'Anić', 'peroanic@email.com', 'peroanic', 'peroanic', NULL, 100),
(2, 'Maja', 'Majić', 'maja@maja.com', 'maja', '$2y$10$MaVy.iQ.liumK1ahxLFGbOVplY5H6.oP6PfVTQMqWn65I8HM3ePcS', 'qUVAh9f9PbWjwZJqojFheISweoGpZk6Dlj7i0B54j6wRQ3UV8IpSUL465U7w', 0),
(3, 'Miro', 'Mirić', 'mmiric@email.com', 'mmiric', '$2y$10$Kj01EOGQJF0KoIyaRSpGUecdRVLbfYKoqw19ZhO72QmIzuT8U9lle', NULL, 0),
(4, 'Ana', 'Anić', 'aanic@email.com', 'aanic', '$2y$10$mfCMedbDS8iTW9KCHzvtGOacp6Hpk9pq.AMYWByc5D8gwzecItDo.', NULL, 0),
(5, 'Ivan', 'Iviž', 'i@email.com', 'iiviz', '$2y$10$ttvCsXWJbraIEE89AJzJIeImwnRU4ZxZVND6HzrrK6Ux3VrfZxLIq', 'Qzpi2zQlA5jNM4hjAGZUlfUQOebQuSONgdws6R1nv7BzuNyRC4NY6G6cvrPG', 0),
(6, 'Sara', 'Sarić', 'ssaric@email.com', 'ssaric', '$2y$10$au/cu.RrF0.gzB95bvulIOlNmCk0MJfeeM8c81zRUscbGpugvbCTe', 'q4vOcLP77adlrM3fPzHynICxS2qlr2j3BIo3QaDUx0om6qdTLtPEkHpEDeFV', 0);

-- --------------------------------------------------------

--
-- Table structure for table `vjezba`
--

CREATE TABLE `vjezba` (
  `id_vjezbe` int(11) NOT NULL,
  `id_korisnika` int(11) NOT NULL,
  `naziv_vjezbe` varchar(200) NOT NULL,
  `broj_serija` int(11) DEFAULT NULL,
  `broj_ponavljanja` int(11) DEFAULT NULL,
  `trajanje` varchar(50) DEFAULT NULL,
  `video_link` text,
  `opis` mediumtext NOT NULL,
  `datum` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vjezba`
--

INSERT INTO `vjezba` (`id_vjezbe`, `id_korisnika`, `naziv_vjezbe`, `broj_serija`, `broj_ponavljanja`, `trajanje`, `video_link`, `opis`, `datum`) VALUES
(1, 2, 'Trčanje', NULL, NULL, '10 min', NULL, 'Trčanje 10 min', '2018-12-13'),
(2, 2, 'Trbušnjaci', 3, 15, NULL, NULL, '3 serija, 15 ponavljanja', '2018-12-15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `korisnik`
--
ALTER TABLE `korisnik`
  ADD PRIMARY KEY (`id_korisnika`),
  ADD UNIQUE KEY `korisnicko_ime` (`korisnicko_ime`);

--
-- Indexes for table `vjezba`
--
ALTER TABLE `vjezba`
  ADD PRIMARY KEY (`id_vjezbe`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `korisnik`
--
ALTER TABLE `korisnik`
  MODIFY `id_korisnika` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `vjezba`
--
ALTER TABLE `vjezba`
  MODIFY `id_vjezbe` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
