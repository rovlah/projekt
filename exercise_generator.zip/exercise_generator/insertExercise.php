<?php
include 'controllers/ExerciseController.php'; 
$isAuth = false;

if(isset($_SESSION['auth'])) { // 1. uvjet
    if($_SESSION['auth'] == true) { // 2. uvjet
        $isAuth = $_SESSION['auth'];
    } // kraj 2. uvjeta
    else 
    { // 2. else uvjet
        header('location: index.php');
    } // keaj 2. else uvjeta
} // kraj 1. uvjeta

if($isAuth == false) { 
    die('Pristup zabranjen'); 
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    if(!empty($_POST)) {
        $notValid = [];
        $data = [];
        foreach($_POST as $key => $value) {
            if($key != 'insertContact') {
                if($key == 'brojSerija' || 'brojPonavljanja' || 'trajanje' || 'poveznicaVideo') {
                    $data[$key] = !empty($value) ? $value : '';
                } else {
                    if(!empty($value)) {
                        $data[$key] = $value;
                    } else {
                        $notValid[] = $key;
                    }
                }
            }
        }


        if(empty($notValid)) {
            $_SESSION['error-insert'] = '';
            $exercise = new ExerciseController(DB_DSN, DB_USERNAME, DB_PASSWORD);
            $exercise->insertExercise($data);
        } else {
            $_SESSION['error-insert'] = "Molimo unesite sve podatke označene zvjezdicom";
            header('location: insertExercise.php');
        }
    } else {
        $_SESSION['error-insert'] = "Molimo unesite sve podatke označene zvjezdicom";
        header('location: insertExercise.php');
    }
}


?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Unos novog kontakta</title>
        <?php include 'assets/css.php'; ?>
    </head>
    <body>
        <div class="container">
            <h1>Unos nove vježbe</h1>
            <hr>
            <?php include 'assets/navigation.php'; ?>
            
                <h3>Unesite novu vježbu</h3>
                <hr>
                <?php if(isset($_SESSION['error-insert'])): ?>
                    <?php if(!empty($_SESSION['error-insert'])): ?>
                        <div class="alert alert-danger"><?php echo $_SESSION['error-insert']; ?></div>
                    <?php endif; ?>
                <?php endif; ?>
                <form class="col-md-4 offset-md-2" action="" method="post">
                    <input type="hidden" name="user" value="<?php echo $_SESSION['id']; ?>" />
                    <div class="form-group">
                        <label>Naziv vježbe*</label>
                        <input type="text" class="form-control" name="nazivVjezbe" />
                    </div>
					<div class="form-group">
                        <label>Broj serija</label>
                        <input type="text" class="form-control" name="brojSerija" />
                    </div>
					<div class="form-group">
                        <label>Broj ponavljanja</label>
                        <input type="text" class="form-control" name="brojPonavljanja" />
                    </div>
					<div class="form-group">
                        <label>Trajanje</label>
                        <input type="text" class="form-control" name="trajanje" />
                    </div>
					<div class="form-group">
                        <label>Poveznica videozapisa</label>
                        <input type="text" class="form-control" name="poveznicaVideo" />
                    </div>
                    <div class="form-group">
                        <label>Opis*</label>
                        <textarea name="opis" class="form-control" cols="30" rows="10"></textarea>
                    </div>
                    <input name="insertExercise" type="submit" value="Spremi vježbu!" />
                </form>
           
        </div>
        <?php include 'assets/js.php'; ?>
    </body>
</html>