<?php
include 'controllers/ExerciseController.php'; 
$isAuth = false;

if(isset($_SESSION['auth'])) { // 1. uvjet
    if($_SESSION['auth'] == true) { // 2. uvjet
        $isAuth = $_SESSION['auth'];
    } // kraj 2. uvjeta
    else 
    { // 2. else uvjet
        header('location: index.php');
    } // keaj 2. else uvjeta
} // kraj 1. uvjeta

if($isAuth == false) { 
    die('Pristup zabranjen'); 
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    if(!empty($_POST)) {
        $notValid = [];
        $data = [];
        foreach($_POST as $key => $value) {
            if($key != 'insertContact') {
                if($key == 'brojSerija' || 'brojPonavljanja' || 'trajanje' || 'poveznicaVideo') {
                    $data[$key] = !empty($value) ? $value : '';
                } else {
                    if(!empty($value)) {
                        $data[$key] = $value;
                    } else {
                        $notValid[] = $key;
                    }
                }
            }
        }


        if(empty($notValid)) {
            $_SESSION['error-insert'] = '';
            $exercise = new ExerciseController(DB_DSN, DB_USERNAME, DB_PASSWORD);
            $exercise->insertExercise($data);
        } else {
            $_SESSION['error-insert'] = "Molimo unesite sve podatke označene zvjezdicom";
            header('location: insertExercise.php');
        }
    } else {
        $_SESSION['error-insert'] = "Molimo unesite sve podatke označene zvjezdicom";
        header('location: insertExercise.php');
    }
}


?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Unos nove vježbe | Exercise Generator</title>
        <?php include 'assets/css.php'; ?>
    </head>
    <body>
        <div class="container text-center">
		<div class="col-md-6">
            <h1 class="text-center" style="font-size: 50px; font-family: Garamond; color: grey; ">Unos nove vježbe</h1>
            <hr>
            <?php include 'assets/navigation.php'; ?>
                <hr>
                <?php if(isset($_SESSION['error-insert'])): ?>
                    <?php if(!empty($_SESSION['error-insert'])): ?>
                        <div class="alert alert-danger"><?php echo $_SESSION['error-insert']; ?></div>
                    <?php endif; ?>
                <?php endif; ?>
                <form class="col-md-12" action="" method="post">
                    <input type="hidden" name="user" value="<?php echo $_SESSION['id']; ?>" />
                    <div class="form-group">
                        <label>Naziv vježbe*</label>
                        <input type="text" class="form-control" name="nazivVjezbe" />
                    </div>
					<div class="form-group">
                        <label>Broj serija</label>
						<p style="font-size: 12px;">-> odnosi se na vježbe snage (rameni potisak, čučnjevi, trbušnjaci, ...)</p>
                        <input type="text" class="form-control" name="brojSerija" />
                    </div>
					<div class="form-group">
                        <label>Broj ponavljanja</label>
						<p style="font-size: 12px;">-> odnosi se na vježbe snage (rameni potisak, čučnjevi, trbušnjaci, ...)</p>
                        <input type="text" class="form-control" name="brojPonavljanja" />
                    </div>
					<div class="form-group">
                        <label>Trajanje</label>
						<p style="font-size: 12px;">-> odnosi se na kondicijske vježbe (trčanje, orbitrek, brzo hodanje, ...)</p>
                        <input type="text" class="form-control" name="trajanje" />
                    </div>
					<div class="form-group">
                        <label>Poveznica videozapisa</label>
						<p style="font-size: 12px;">-> za lakše razumijevanje postavite poveznicu s videozapisom u kojem je objašnjena vježba</p>
                        <input type="text" class="form-control" name="poveznicaVideo" />
                    </div>
                    <div class="form-group">
                        <label>Opis vježbe*</label>
                        <textarea name="opis" class="form-control" cols="30" rows="10"></textarea>
                    </div>
                    <input class="btn btn-info" name="insertExercise" type="submit" value="Spremi vježbu!" />
					<a href="profile.php" class="btn btn-info">Povratak na profil</a>
                </form>
           </div>
        </div>
        <?php include 'assets/js.php'; ?>
    </body>
</html>