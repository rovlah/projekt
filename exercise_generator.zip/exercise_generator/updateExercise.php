<?php 
    include 'controllers/ExerciseController.php';
    $isValid = false;

    if($_SESSION['auth'] != true) { 
        die('Pristup zabranjen'); 
    }

    if(isset($_GET['exercise'])) {
        $isValid = true;
    }

    //Ako ne postoji get varijabla contact onda prekini kod
    if($isValid != true) {
        die('Pristup zabranjen'); 
    }

    //Dohvat podataka o kontaktu
    $exercise = new ExerciseController(DB_DSN, DB_USERNAME, DB_PASSWORD);
    $exerciseData = $exercise->exerciseData($_GET['exercise'], $_SESSION['id']);

?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Izmjena vježbe | Exercise Generator</title>
        <?php include 'assets/css.php'; ?>
    </head>
    <body>
        <div class="container text-center">
		<div class="col-md-6">
            <h1 class="text-center" style="font-size: 50px; font-family: Garamond; color: grey; ">Izmjena vježbe</h1>
            <hr>
            <?php include 'assets/navigation.php'; ?>
                <hr>
                <?php if(isset($_SESSION['error-update'])): ?>
                    <?php if(!empty($_SESSION['error-update'])): ?>
                        <div class="alert alert-danger"><?php echo $_SESSION['error-update']; ?></div>
                    <?php endif; ?>
                <?php endif; ?>
                <form class="col-md-12" action="update.php" method="post">
                    <input type="hidden" name="user" value="<?php echo $_SESSION['id']; ?>" />
                    <input type="hidden" name="exercise" value="<?php echo $_GET['exercise']; ?>" />
                    <div class="form-group">
                        <label>Naziv vježbe*</label>
                        <input type="text" class="form-control" name="nazivVjezbe" value="<?php echo $exerciseData['naziv_vjezbe']; ?>" />
                    </div>
					<div class="form-group">
                        <label>Broj serija</label>
						<p style="font-size: 12px;">-> odnosi se na vježbe snage (rameni potisak, čučnjevi, trbušnjaci, ...)</p>
                        <input type="text" class="form-control" name="brojSerija" value="<?php echo $exerciseData['broj_serija']; ?>" />
                    </div>
					<div class="form-group">
                        <label>Broj ponavljanja</label>
						<p style="font-size: 12px;">-> odnosi se na vježbe snage (rameni potisak, čučnjevi, trbušnjaci, ...)</p>
                        <input type="text" class="form-control" name="brojPonavljanja" value="<?php echo $exerciseData['broj_ponavljanja']; ?>" />
                    </div>
					<div class="form-group">
                        <label>Trajanje</label>
						<p style="font-size: 12px;">-> odnosi se na kondicijske vježbe (trčanje, orbitrek, brzo hodanje, ...)</p>
                        <input type="text" class="form-control" name="trajanje" value="<?php echo $exerciseData['trajanje']; ?>" />
                    </div>
					<div class="form-group">
                        <label>Poveznica videozapisa</label>
						<p style="font-size: 12px;">-> za lakše razumijevanje postavite poveznicu s videozapisom u kojem je objašnjena vježba</p>
                        <input type="text" class="form-control" name="poveznicaVideo" value="<?php echo $exerciseData['video_link']; ?>" />
                    </div>
                    <div class="form-group">
                        <label>Opis vježbe*</label>
                        <textarea name="opis" class="form-control" cols="30" rows="10"><?php echo $exerciseData['opis']; ?></textarea>
                    </div>
                    <input class="btn btn-info" name="updateExercise" type="submit" value="Ažuriraj vježbu!" />
					<a href="profile.php" class="btn btn-info">Povratak na profil</a>
                </form>
           </div>
        </div>
        <?php include 'assets/js.php'; ?>
    </body>
</html>